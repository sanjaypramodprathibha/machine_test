# Interview Testing Guide - Django REST API

## 🚀 Quick Setup (30 seconds)
```bash
cd /path/to/project
source venv/bin/activate
python manage.py runserver
```
**Server starts at:** `http://127.0.0.1:8000/`

---

## 🧪 API Testing Commands

### 1. User Registration API (`/register/`)
**Test Valid Registration:**
```bash
curl -X POST http://127.0.0.1:8000/register/ \
  -H "Content-Type: application/json" \
  -d '{"username": "interviewuser", "email": "interview@example.com", "password": "password123", "password_confirm": "password123"}'
```

**Test Validation Errors:**
```bash
curl -X POST http://127.0.0.1:8000/register/ \
  -H "Content-Type: application/json" \
  -d '{"username": "ab", "email": "invalid", "password": "short", "password_confirm": "different"}'
```

### 2. User Management API

**Get All Users:**
```bash
curl http://127.0.0.1:8000/users/
```

**Get User by ID:**
```bash
curl http://127.0.0.1:8000/users/1/
```

**Delete User:**
```bash
curl -X DELETE http://127.0.0.1:8000/users/2/
```

### 3. Expense Management API

**Get All Categories:**
```bash
curl http://127.0.0.1:8000/categories/
```

**Create New Category:**
```bash
curl -X POST http://127.0.0.1:8000/categories/ \
  -H "Content-Type: application/json" \
  -d '{"name": "Healthcare"}'
```

**Get All Expenses:**
```bash
curl http://127.0.0.1:8000/expenses/
```

**Create New Expense:**
```bash
curl -X POST http://127.0.0.1:8000/expenses/ \
  -H "Content-Type: application/json" \
  -d '{"title": "Doctor visit", "amount": "100.00", "category": 1, "date": "2025-10-07"}'
```

### 4. Expense Summary API (Main Requirement)
```bash
curl http://127.0.0.1:8000/expenses/summary/
```

**Expected Response:**
```json
{
    "Entertainment": 95.0,
    "Food": 150.75,
    "Healthcare": 100.0,
    "Shopping": 150.0,
    "Travel": 550.0,
    "Utilities": 85.5
}
```

---

## 🎯 Key Points to Mention

### **Validation Rules:**
- **Username**: Minimum 5 characters, unique
- **Email**: Valid format, unique
- **Password**: Minimum 8 characters, must contain at least one number

### **Database Relationships:**
- **Category** ↔ **Expense** (Foreign Key)
- **User** ↔ **Expense** (Foreign Key)

### **Django ORM Aggregation:**
- Uses `Sum()` aggregation in expense summary
- Groups by category name
- Efficient database queries

### **HTTP Status Codes:**
- `201` - Created (registration, expense creation)
- `200` - OK (GET requests)
- `204` - No Content (DELETE)
- `400` - Bad Request (validation errors)
- `404` - Not Found (invalid IDs)

---

## 🔧 Populate Sample Data (if needed)
```bash
python manage.py populate_sample_data
```

---

## 🌐 Browser Testing (Alternative)
Visit these URLs in your browser:
- `http://127.0.0.1:8000/users/` - Browse all users
- `http://127.0.0.1:8000/categories/` - Browse all categories
- `http://127.0.0.1:8000/expenses/` - Browse all expenses
- `http://127.0.0.1:8000/expenses/summary/` - View expense summary

---

## 📋 Quick Demo Script

**For a 5-minute demo:**

1. **Start server:** `python manage.py runserver`
2. **Show user registration:** Use the valid registration curl command
3. **Show validation:** Use the invalid registration curl command
4. **Show user list:** `curl http://127.0.0.1:8000/users/`
5. **Show expense summary:** `curl http://127.0.0.1:8000/expenses/summary/`
6. **Create new expense:** Use the expense creation curl command
7. **Show updated summary:** `curl http://127.0.0.1:8000/expenses/summary/`

---

## 💡 Technical Highlights to Mention

1. **Django 5.2.7** with **Django REST Framework 3.16.1**
2. **Custom User Model** extending AbstractUser
3. **SQLite Database** with proper migrations
4. **Django ORM Aggregation** for expense summaries
5. **Comprehensive Validation** with detailed error messages
6. **REST API Best Practices** with proper HTTP methods and status codes
7. **Complete Documentation** with setup instructions
8. **Sample Data Management** command for testing

---

## 🚨 Troubleshooting

**If server won't start:**
```bash
source venv/bin/activate
pip install -r requirements.txt
python manage.py migrate
python manage.py runserver
```

**If no data exists:**
```bash
python manage.py populate_sample_data
```

**If virtual environment issues:**
```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

---

## ✅ Success Indicators

- All curl commands return JSON responses
- User registration creates new users
- Validation errors show detailed messages
- Expense summary shows aggregated data by category
- All HTTP status codes are appropriate
- No server errors in terminal
