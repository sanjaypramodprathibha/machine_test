# GitHub Repository Setup Guide

## For Your Friend (Repository Owner)

### Step 1: Create a New Repository on GitHub
1. Go to [GitHub.com](https://github.com) and sign in
2. Click the "+" icon in the top right corner
3. Select "New repository"
4. Fill in the details:
   - **Repository name**: `django-machine-test` (or any name you prefer)
   - **Description**: `Django REST API Machine Test Project`
   - **Visibility**: Choose Public or Private
   - **DO NOT** initialize with README, .gitignore, or license (since we already have these files)
5. Click "Create repository"

### Step 2: Add You as a Collaborator
1. Go to your newly created repository
2. Click on "Settings" tab
3. In the left sidebar, click "Manage access"
4. Click "Invite a collaborator"
5. Enter your friend's GitHub username or email
6. Select "Write" permissions (so they can push code)
7. Click "Add [username] to this repository"

### Step 3: Share Repository Details
Send these details to your friend:
- Repository URL: `https://github.com/[your-username]/[repository-name].git`
- Their GitHub username (for the push commands)

---

## For You (Code Contributor)

Once your friend has set up the repository and added you as a collaborator, use these commands to push your code:

### Step 1: Initialize Git and Add Remote
```bash
cd /home/abhijith/Documents/SanjayPP
git init
git remote add origin https://github.com/[friend's-username]/[repository-name].git
```

### Step 2: Add All Files and Commit
```bash
git add .
git commit -m "Initial commit: Django REST API Machine Test Project

- User registration with validation
- User CRUD operations
- Expense tracking with Category and Expense models
- Expense summary with Django ORM aggregation
- Complete API documentation and setup instructions"
```

### Step 3: Push to GitHub
```bash
git branch -M main
git push -u origin main
```

### Optional: Create a Pull Request (if using separate branch)
```bash
git checkout -b feature/django-api-implementation
git add .
git commit -m "Implement Django REST API with all required features"
git push -u origin feature/django-api-implementation
```

Then create a Pull Request on GitHub from the `feature/django-api-implementation` branch to `main`.

---

## Quick Checklist for Your Friend

- [ ] Create new GitHub repository
- [ ] Add you as collaborator with Write permissions
- [ ] Share repository URL with you
- [ ] Confirm you received the invitation

## Quick Checklist for You

- [ ] Clone or initialize git in project directory
- [ ] Add remote origin
- [ ] Stage and commit all files
- [ ] Push to main branch
- [ ] Verify code is visible on GitHub

---

## Repository Contents
Your project includes:
- Complete Django REST API
- User registration and management
- Expense tracking system
- Database models and migrations
- API documentation
- Setup instructions
- Sample data management command
- All dependencies and configuration files

## Contact
If you need help with any step, just ask!
